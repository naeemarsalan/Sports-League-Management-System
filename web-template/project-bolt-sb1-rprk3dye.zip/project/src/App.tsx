import { Trophy, Users, Calendar, Target, Shield, Bell, ArrowRight, Download, Star } from 'lucide-react';

function App() {
  return (
    <div className="bg-[#0a0e14] text-white min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#34d9c3]/10 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6">
                Run Your Snooker League{' '}
                <span className="bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] bg-clip-text text-transparent">
                  Like a Pro
                </span>
              </h1>
              <p className="text-xl text-gray-400 mb-8 leading-relaxed">
                Create leagues, schedule matches, track standings, and challenge players — all from your phone.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <button className="group bg-[#34d9c3] hover:bg-[#2ab3a0] text-[#0a0e14] font-semibold px-8 py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-[#34d9c3]/20 hover:shadow-xl hover:shadow-[#34d9c3]/30 hover:scale-105">
                  <Download className="w-5 h-5" />
                  Download on App Store
                </button>
                <button className="group bg-[#141922] hover:bg-[#1f2937] border-2 border-[#34d9c3]/30 hover:border-[#34d9c3] font-semibold px-8 py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 hover:scale-105">
                  <Download className="w-5 h-5" />
                  Get it on Google Play
                </button>
              </div>
            </div>
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] rounded-[3rem] blur-3xl opacity-20"></div>
                <div className="relative bg-[#141922] rounded-[3rem] p-8 border border-[#34d9c3]/20 shadow-2xl">
                  <div className="w-64 h-[520px] bg-gradient-to-b from-[#0a0e14] to-[#141922] rounded-3xl border-8 border-gray-800 shadow-2xl overflow-hidden">
                    <div className="bg-[#141922] h-full p-4">
                      <div className="text-center mb-6">
                        <h3 className="text-[#34d9c3] font-bold text-lg mb-2">Leaderboard</h3>
                        <div className="h-1 w-16 bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] mx-auto rounded-full"></div>
                      </div>
                      {[
                        { rank: 1, name: 'Alex Chen', points: 24, badge: '🥇' },
                        { rank: 2, name: 'Sarah Jones', points: 21, badge: '🥈' },
                        { rank: 3, name: 'Mike Wilson', points: 18, badge: '🥉' },
                        { rank: 4, name: 'Emma Brown', points: 15, badge: '' },
                        { rank: 5, name: 'John Davis', points: 12, badge: '' },
                      ].map((player) => (
                        <div
                          key={player.rank}
                          className="bg-[#0a0e14] border border-[#34d9c3]/20 rounded-lg p-3 mb-2 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-[#34d9c3] font-bold text-lg w-6">{player.rank}</span>
                            <div>
                              <p className="font-semibold text-sm">{player.name}</p>
                              <p className="text-xs text-gray-500">{player.points} pts</p>
                            </div>
                          </div>
                          {player.badge && <span className="text-2xl">{player.badge}</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">
              Everything You Need to{' '}
              <span className="bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] bg-clip-text text-transparent">
                Manage Your League
              </span>
            </h2>
            <p className="text-xl text-gray-400">Powerful features designed for competitive play</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Trophy,
                title: 'Create & Join Leagues',
                description: 'Start your own league or join with a 6-character invite code',
              },
              {
                icon: Calendar,
                title: 'Match Scheduling',
                description: 'Schedule matches, record scores, and track results in real time',
              },
              {
                icon: Target,
                title: 'Live Leaderboards',
                description: 'Automatic standings with points (3 for win, 1 for draw) and rankings with gold/silver/bronze badges',
              },
              {
                icon: Users,
                title: 'Challenge Players',
                description: 'Send challenges to any player in your league',
              },
              {
                icon: Shield,
                title: 'Role-Based Management',
                description: 'Owner, Admin, Mod, and Player roles with granular permissions',
              },
              {
                icon: Bell,
                title: 'Push Notifications',
                description: 'Get notified about challenges, match updates, and league activity',
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="group bg-[#141922] border border-[#34d9c3]/10 hover:border-[#34d9c3]/40 rounded-2xl p-8 transition-all duration-300 hover:transform hover:scale-105 hover:shadow-xl hover:shadow-[#34d9c3]/10"
              >
                <div className="bg-gradient-to-br from-[#34d9c3] to-[#2ab3a0] w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-7 h-7 text-[#0a0e14]" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-[#141922]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-gray-400">Get started in three simple steps</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Create a League',
                description: 'Set up your league and share the invite code with your players',
              },
              {
                step: '02',
                title: 'Add Players',
                description: 'Members join with the code and get approved by league admins',
              },
              {
                step: '03',
                title: 'Play & Compete',
                description: 'Schedule matches, record results, and climb the leaderboard',
              },
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-[#141922] border border-[#34d9c3]/20 rounded-2xl p-8 h-full hover:border-[#34d9c3]/40 transition-all duration-300">
                  <div className="text-6xl font-bold bg-gradient-to-br from-[#34d9c3] to-[#2ab3a0] bg-clip-text text-transparent mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{item.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{item.description}</p>
                </div>
                {index < 2 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="w-8 h-8 text-[#34d9c3]" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Screenshot/App Preview Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">
              Beautiful Dark UI{' '}
              <span className="bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] bg-clip-text text-transparent">
                Designed for Focus
              </span>
            </h2>
            <p className="text-xl text-gray-400">A seamless experience across all features</p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {['Dashboard', 'Matches', 'Leaderboard', 'Profile'].map((screen, index) => (
              <div key={index} className="group">
                <div className="relative bg-gradient-to-b from-[#141922] to-[#0a0e14] rounded-3xl border-4 border-gray-800 overflow-hidden aspect-[9/16] hover:scale-105 transition-transform duration-300 shadow-xl">
                  <div className="absolute top-0 left-0 right-0 h-8 bg-gray-900 flex items-center justify-center">
                    <div className="w-24 h-5 bg-gray-800 rounded-full"></div>
                  </div>
                  <div className="p-6 pt-12 h-full">
                    <div className="bg-[#0a0e14] rounded-lg h-full border border-[#34d9c3]/20 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-[#34d9c3] to-[#2ab3a0] rounded-2xl mx-auto mb-4 flex items-center justify-center">
                          {index === 0 && <Trophy className="w-8 h-8 text-[#0a0e14]" />}
                          {index === 1 && <Calendar className="w-8 h-8 text-[#0a0e14]" />}
                          {index === 2 && <Target className="w-8 h-8 text-[#0a0e14]" />}
                          {index === 3 && <Users className="w-8 h-8 text-[#0a0e14]" />}
                        </div>
                        <p className="text-[#34d9c3] font-semibold">{screen}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-[#141922]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">Trusted by League Organizers</h2>
            <p className="text-xl text-gray-400">See what players and organizers are saying</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: 'Marcus Thompson',
                role: 'League Owner',
                content: 'Managing our local snooker league has never been easier. The automated leaderboard saves me hours every week.',
              },
              {
                name: 'Sophie Martinez',
                role: 'League Admin',
                content: 'The challenge system keeps our league active and competitive. Players love being able to compete anytime.',
              },
              {
                name: 'David Chen',
                role: 'Player',
                content: 'Finally, a league app that actually works! Clean interface, real-time updates, and the dark theme is perfect for late-night matches.',
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-[#141922] border border-[#34d9c3]/20 rounded-2xl p-8 hover:border-[#34d9c3]/40 transition-all duration-300"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#34d9c3] text-[#34d9c3]" />
                  ))}
                </div>
                <p className="text-gray-300 mb-6 leading-relaxed italic">"{testimonial.content}"</p>
                <div>
                  <p className="font-bold">{testimonial.name}</p>
                  <p className="text-sm text-[#34d9c3]">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#34d9c3]/20 via-[#2ab3a0]/10 to-transparent"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">Ready to Start Your League?</h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of players competing in organized snooker and pool leagues worldwide
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="group bg-[#34d9c3] hover:bg-[#2ab3a0] text-[#0a0e14] font-semibold px-8 py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-[#34d9c3]/20 hover:shadow-xl hover:shadow-[#34d9c3]/30 hover:scale-105">
              <Download className="w-5 h-5" />
              Download on App Store
            </button>
            <button className="group bg-[#141922] hover:bg-[#1f2937] border-2 border-[#34d9c3]/30 hover:border-[#34d9c3] font-semibold px-8 py-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 hover:scale-105">
              <Download className="w-5 h-5" />
              Get it on Google Play
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#141922] border-t border-[#34d9c3]/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold bg-gradient-to-r from-[#34d9c3] to-[#2ab3a0] bg-clip-text text-transparent mb-2">
                Snooker Pool League
              </h3>
              <p className="text-gray-400 text-sm">Professional league management in your pocket</p>
            </div>
            <div className="flex gap-8 text-sm">
              <a href="#" className="text-gray-400 hover:text-[#34d9c3] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-[#34d9c3] transition-colors">
                Terms
              </a>
              <a href="#" className="text-gray-400 hover:text-[#34d9c3] transition-colors">
                Contact
              </a>
            </div>
          </div>
          <div className="text-center mt-8 pt-8 border-t border-[#34d9c3]/10">
            <p className="text-gray-500 text-sm">© 2026 Snooker Pool League. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
